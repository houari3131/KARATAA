// ==UserScript==
// @name         CLIK BOOK APPOTMENT
// @namespace    http://tampermonkey.net/
// @version      2024-08-29
// @description  try to take over the world!
// @author       You
// @match        https://algeria.blsspainglobal.com/DZA/account/changepassword?alert=True
// @match        https://algeria.blsspainglobal.com/dza/home/index
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.querySelector("#navbarCollapse2 > ul > li:nth-child(2) > a").click();
})();